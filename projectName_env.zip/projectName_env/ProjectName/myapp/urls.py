from django.urls import path
from . import views

urlpatterns = [
    # URL for home view (list of people)
    path('', views.home, name='home'),

    # URL for add-person view (form to add new person)
    path('add/', views.add_person, name='add_person'),
]
