# myapp/views.py
from django.shortcuts import render, redirect

# Define the Person class
class Person:
    def __init__(self, username, password):
        self.username = username
        self.password = password

# List to store Person objects
people = []

# View to add a person
def add_person(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        new_person = Person(username, password)
        people.append(new_person)
        return redirect('home')
    return render(request, 'myapp/add_person.html')

# View to display all people
def home(request):
    return render(request, 'myapp/home.html', {'people': people})

